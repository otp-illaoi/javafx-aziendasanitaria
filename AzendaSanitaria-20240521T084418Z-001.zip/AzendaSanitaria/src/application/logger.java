package application;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class logger {
    private static final String LOG_FILE = "log.txt";

    public static void scriviLog(String messaggio) {
        System.out.println(messaggio); 
        scriviSuFile(getTimestamp() + " - " + messaggio);
    }


    private static void scriviSuFile(String messaggio) {
        try (FileWriter fileWriter = new FileWriter(LOG_FILE, true);
             PrintWriter printWriter = new PrintWriter(fileWriter)) {
            printWriter.println(messaggio);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getTimestamp() {
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return dateTime.format(formatter);
    }
}
