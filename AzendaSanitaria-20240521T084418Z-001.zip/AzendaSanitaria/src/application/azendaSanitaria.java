package application;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
public class azendaSanitaria {
	private ArrayList<Medico> elencoMedici;
    private ArrayList<paziente> elencoPazienti;
    private  logger Logger;
    

        public azendaSanitaria() {
            this.elencoMedici = new ArrayList<>();
            this.elencoPazienti = new ArrayList<>();
            this.Logger = new logger(); 
        }
        
        public boolean medicoEsiste(String idMedico) {
            try (BufferedReader reader = new BufferedReader(new FileReader("dati_medici.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length > 0 && parts[0].equals(idMedico)) {
                        return true; 
                    }
                }
            } catch (IOException e) {
                System.err.println("Errore durante la lettura del file dati_medici.txt: " + e.getMessage());
            }
            return false; 
        }

        public void aggiungiMedico(Medico Medico) {
            elencoMedici.add(Medico);
            logger.scriviLog("Aggiunto medico: " + Medico.getNome() + " " + Medico.getCognome());
        }

        public void rimuoviMedico(Medico Medico) {
            if (!Medico.getPazienti().isEmpty()) {
                System.out.println("Impossibile rimuovere il medico: ha pazienti assegnati.");
                return;
            }
            elencoMedici.remove(Medico);
            logger.scriviLog("Rimosso medico: " + Medico.getNome() + " " + Medico.getCognome());
        }

        public void aggiungiPaziente(paziente paziente) {
            elencoPazienti.add(paziente);
            logger.scriviLog("Aggiunto paziente: " + paziente.getNome() + " " + paziente.getCognome());
        }

        public void rimuoviPaziente(paziente paziente) {
            String medicoNome = paziente.getMedico();
            if (medicoNome != null) {
                for (Medico medico : elencoMedici) {
                    if (medico.getNome().equals(medicoNome)) {
                        medico.rimuoviPaziente(paziente);
                        break;
                    }
                }
            }
            elencoPazienti.remove(paziente);
            logger.scriviLog("Rimosso paziente: " + paziente.getNome() + " " + paziente.getCognome());
        }

        public void cambiaMedicoPaziente(paziente paziente, Medico nuovoMedico) {
            String vecchioMedicoNome = paziente.getMedico();
            if (vecchioMedicoNome != null) {
                for (Medico medico : elencoMedici) {
                    if (medico.getNome().equals(vecchioMedicoNome)) {
                        medico.rimuoviPaziente(paziente);
                        break;
                    }
                }
            }
            nuovoMedico.aggiungiPaziente(paziente);
            paziente.setMedico(nuovoMedico.getNome());
            logger.scriviLog("Paziente " + paziente.getNome() + " " + paziente.getCognome() +
                    " cambiato al medico: " + nuovoMedico.getNome() + " " + nuovoMedico.getCognome());
        }
        
        public void modificaMedico(String id, String nome, String cognome, String telefono) {
            
            ArrayList<Medico> mediciAggiornati = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader("dati_medici.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts[0].equals(id)) {
                       
                        mediciAggiornati.add(new Medico(id, nome, cognome, telefono));
                    } else {
                      
                        mediciAggiornati.add(new Medico(parts[0], parts[1], parts[2], parts[3]));
                    }
                }
            } catch (IOException e) {
                System.err.println("Errore durante la lettura dei dati medici: " + e.getMessage());
                e.printStackTrace();
            }

           
            try (PrintWriter writer = new PrintWriter(new FileWriter("dati_medici.txt"))) {
                for (Medico medico : mediciAggiornati) {
                    writer.println(medico.getIdMedico() + "," + medico.getNome() + "," + medico.getCognome() + "," + medico.getTelefono());
                }
                System.out.println("Dati medici aggiornati su file.");
            } catch (IOException e) {
                System.err.println("Errore durante la scrittura dei dati medici: " + e.getMessage());
                e.printStackTrace();
            }
        }

        
        public void modificaPaziente(String IDPAT, String nome, String cognome, String telefono, String idmedico) {
          
            ArrayList<paziente> pazientiAggiornati = new ArrayList<>();

           
            try (BufferedReader reader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts[0].equals(IDPAT)) {
                        
                        pazientiAggiornati.add(new paziente(IDPAT, nome, cognome, telefono,idmedico));
                    } else {

                        pazientiAggiornati.add(new paziente(parts[0], parts[1], parts[2], parts[3],parts[4]));
                    }
                }
            } catch (IOException e) {
                System.err.println("Errore durante la lettura dei dati pazienti: " + e.getMessage());
                e.printStackTrace();
            }

            
            try (PrintWriter writer = new PrintWriter(new FileWriter("dati_pazienti.txt"))) {
                for (paziente paziente : pazientiAggiornati) {
                    writer.println(paziente.getIdPaziente() + "," + paziente.getNome() + "," + paziente.getCognome() + "," + paziente.getTelefono() +"," +paziente.getMedico());
                }
                System.out.println("Dati pazienti aggiornati su file.");
            } catch (IOException e) {
                System.err.println("Errore durante la scrittura dei dati pazienti: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        public boolean haPazientiAssociati(String medicoId) {
            try (BufferedReader reader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 5 && parts[4].equals(medicoId)) {
                        System.out.println("Paziente associato trovato per il medico con ID: " + medicoId);
                        return true;
                    }
                }
            } catch (IOException e) {
                System.err.println("Errore durante la lettura del file dati_pazienti.txt: " + e.getMessage());
                e.printStackTrace();
            }
            System.out.println("Nessun paziente associato trovato per il medico con ID: " + medicoId);
            return false;
        }




        
        

        public  ArrayList<Medico> getElencoMedici() {
            return elencoMedici;
        }
        
        public ArrayList<paziente> getElencoPaziente(){
			return elencoPazienti;
        	
        }

		
}
