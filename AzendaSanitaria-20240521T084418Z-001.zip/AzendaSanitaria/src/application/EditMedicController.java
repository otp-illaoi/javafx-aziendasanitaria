package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditMedicController {
    @FXML
    private Button EXIT;

    @FXML
    private Button modifica;

    @FXML
    private TextField cognomeField;

    @FXML
    private TextField idField;

    @FXML
    private TextField idpat;

    @FXML
    private TextField idmed;

    @FXML
    private TextField nameField;

    @FXML
    private TextField telField;

    private Medico medico;

    private Stage stagee;

    private Stage stageee;

    public void setStage(Stage stageee) {
        this.stageee = stageee;
    }

    private azendaSanitaria azienda;

    private paziente PAZIENTE;

    public EditMedicController() {
        this.azienda = new azendaSanitaria();
    }

    public void setAzenda(azendaSanitaria azienda) {
        this.azienda = azienda;
    }

    public void initData(Medico medico) {
        this.medico = medico;
        idField.setText(medico.getIdMedico());
        nameField.setText(medico.getNome());
        cognomeField.setText(medico.getCognome());
        telField.setText(medico.getTelefono());
    }

    public void initDataP(paziente paziente) {
        this.PAZIENTE = paziente;
        idpat.setText(PAZIENTE.getIdPaziente());
        nameField.setText(PAZIENTE.getNome());
        cognomeField.setText(PAZIENTE.getCognome());
        telField.setText(PAZIENTE.getTelefono());
        idmed.setText(PAZIENTE.getMedico());
    }

    @FXML
    private void modifica(ActionEvent event) {
        String newMedicoId = idField.getText();
        String newMedicoNome = nameField.getText();
        String newMedicoCognome = cognomeField.getText();
        String newMedicoTelefono = telField.getText();

        if (azienda != null) {
            azienda.modificaMedico(newMedicoId, newMedicoNome, newMedicoCognome, newMedicoTelefono);
            logger.scriviLog("Modifica medico: " + newMedicoNome + " " + newMedicoCognome + " (ID: " + newMedicoId + ")");
        } else {
            System.err.println("Errore: istanza di AzendaSanitaria non impostata correttamente.");
        }

        chiudiFinestra();
    }

    @FXML
    public void modificaPA(ActionEvent event) {
        String newPazienteId = idpat.getText();
        String newPazienteNome = nameField.getText();
        String newPazienteCognome = cognomeField.getText();
        String newPazienteTelefono = telField.getText();
        String newPazienteIdMedico = idmed.getText();

       
        boolean medicoEsiste = azienda.medicoEsiste(newPazienteIdMedico);
        if (!medicoEsiste) {
            showAlert("ID Medico non valido", "L'ID medico specificato non esiste. Inserisci un ID medico valido.");
            return; 
        }

        if (azienda != null) {
            azienda.modificaPaziente(newPazienteId, newPazienteNome, newPazienteCognome, newPazienteTelefono, newPazienteIdMedico);
            logger.scriviLog("Modifica paziente: " + newPazienteNome + " " + newPazienteCognome + " (ID: " + newPazienteId + ")");
        } else {
            System.err.println("Errore: istanza di AzendaSanitaria non impostata correttamente.");
        }

        chiudiFinestra();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    @FXML
    private void chiudiFinestra() {
        try {
            if (stageee != null) {
                stageee.close();
            } else {
                System.err.println("Errore: stagee � null");
            }
        } catch (Exception e) {
            System.err.println("Errore durante la chiusura della finestra: " + e.getMessage());
        }
    }

}
