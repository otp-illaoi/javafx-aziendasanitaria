package application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javafx.scene.Node;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SampleControllerMain {
	 @FXML
	    private Button visualizzaMedico;

	    @FXML
	    private Button visualizzaDatiMediciPazienti;

	    @FXML
	    private Button modificaMedico;

	    @FXML
	    private Button modificaPAT;

	    @FXML
	    private Button AddDoc;

	    @FXML
	    private Button AddPat;

	    @FXML
	    private Button cambiaMedicoPaziente;

	    @FXML
	    private Button DelMedico;

	    @FXML
	    private Button DelPatient;

	    @FXML
	    private TextArea DATIPAT;

	    @FXML
	    private TextArea DATIMEDICO;

	    private azendaSanitaria azienda;
	    
	    @FXML
	    private TableView<Medico> tableViewMedico;

	    @FXML
	    private TableColumn<Medico, String> columnIdMedico;
	    
	    @FXML
	    private TableColumn<Medico, String> columnNomeMedico;
	    
	    @FXML
	    private TableColumn<Medico, String> columnCognomeMedico;
	    
	    @FXML
	    private TableColumn<Medico, String> columnTeleMedico;

	    @FXML
	    private TableView<paziente> tableViewPaziente;

	    @FXML
	    private TableColumn<paziente, String> columnIdPaziente;
	    
	    @FXML
	    private TableColumn<paziente, String> columnNomePaziente;
	    
	    @FXML
	    private TableColumn<paziente, String> columnCognomePaziente;
	    
	    @FXML
	    private TableColumn<paziente, String> columnTelePaziente;

	    @FXML
	    private TableColumn<paziente, String> columnIdMedicoPaziente;
    
	    @FXML
	    private TextField ciao;
	    
	    @FXML
	    public void initialize() {
	        columnIdMedico.setCellValueFactory(new PropertyValueFactory<>("idMedico"));
	        columnNomeMedico.setCellValueFactory(new PropertyValueFactory<>("nome"));
	        columnCognomeMedico.setCellValueFactory(new PropertyValueFactory<>("cognome"));
	        columnTeleMedico.setCellValueFactory(new PropertyValueFactory<>("telefono"));

	        columnIdPaziente.setCellValueFactory(new PropertyValueFactory<>("idPaziente"));
	        columnNomePaziente.setCellValueFactory(new PropertyValueFactory<>("nome"));
	        columnCognomePaziente.setCellValueFactory(new PropertyValueFactory<>("cognome"));
	        columnTelePaziente.setCellValueFactory(new PropertyValueFactory<>("telefono"));
	        columnIdMedicoPaziente.setCellValueFactory(new PropertyValueFactory<>("medico"));
	    }
    
    public void setAzienda(azendaSanitaria azienda) {
        this.azienda = azienda;
    }

    @FXML
    private void AddDoc(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("addmedic.fxml"));
            Parent root = loader.load();   
            AddDoctorController controller = loader.getController();
            controller.setStage((Stage) ((Node) event.getSource()).getScene().getWindow());
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	@FXML
	private void Addpat(ActionEvent event) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("addpatient.fxml"));
	        Parent root = loader.load();
	        AddPatController controller=loader.getController();
	        controller.setStage((Stage)((Node) event.getSource()).getScene().getWindow());;
	        Scene scene = new Scene(root);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.setScene(scene);
	        stage.show();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	
}
	
	@FXML
	private void visualizzaMedico(ActionEvent event) {
	    String medicoId = ciao.getText();
	    Medico medico = null;
	    ObservableList<paziente> pazientiDelMedico = FXCollections.observableArrayList();

	    try (BufferedReader reader = new BufferedReader(new FileReader("dati_medici.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts[0].equals(medicoId)) {
	                medico = new Medico(parts[0], parts[1], parts[2], parts[3]);
	                break;
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    if (medico != null) {
	        try (BufferedReader reader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts[4].equals(medico.getIdMedico())) {
	                    paziente paziente = new paziente(parts[0], parts[1], parts[2], parts[3], parts[4]);
	                    pazientiDelMedico.add(paziente);
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        ObservableList<Medico> medici = FXCollections.observableArrayList(medico);
	        tableViewMedico.setItems(medici);

	        tableViewPaziente.setItems(pazientiDelMedico);
	    } else {
	        DATIMEDICO.setText("Medico non trovato!");
	    }
	}

	// Metodo visualizzaDatiMediciPazienti aggiornato
	@FXML
	private void visualizzaDatiMediciPazienti(ActionEvent event) {
	    ObservableList<Medico> mediciList = FXCollections.observableArrayList();
	    ObservableList<paziente> pazientiList = FXCollections.observableArrayList();

	    try (BufferedReader mediciReader = new BufferedReader(new FileReader("dati_medici.txt"));
	         BufferedReader pazientiReader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {

	        String line;

	        while ((line = mediciReader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts.length >= 4) {
	                Medico medico = new Medico(parts[0], parts[1], parts[2], parts[3]);
	                mediciList.add(medico);
	            } else {
	                System.err.println("Dati incompleti per il medico: " + line);
	            }
	        }

	        while ((line = pazientiReader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts.length >= 5) {
	                paziente paziente = new paziente(parts[0], parts[1], parts[2], parts[3], parts[4]);
	                pazientiList.add(paziente);
	            } else {
	                System.err.println("Dati incompleti per il paziente: " + line);
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    tableViewMedico.setItems(mediciList);

	    tableViewPaziente.setItems(pazientiList);
	}
/*
	@FXML
	private void visualizzaMedico(ActionEvent event) {
	    azendaSanitaria azienda = new azendaSanitaria();
	    String medicoId = ciao.getText();
	    StringBuilder resultMedico = new StringBuilder();
	    StringBuilder resultPazienti = new StringBuilder();
	    Medico medico = null;
	    try (BufferedReader reader = new BufferedReader(new FileReader("dati_medici.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts[0].equals(medicoId)) {
	                medico = new Medico(parts[0], parts[1], parts[2], parts[3]);
	                break;
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    if (medico != null) {
	        resultMedico.append("Informazioni Medico:\n");
	        resultMedico.append("ID: ").append(medico.getIdMedico()).append("\n");
	        resultMedico.append("Nome: ").append(medico.getNome()).append("\n");
	        resultMedico.append("Cognome: ").append(medico.getCognome()).append("\n");
	        resultMedico.append("Telefono: ").append(medico.getTelefono()).append("\n\n");
	        try (BufferedReader reader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts[4].equals(medico.getIdMedico())) {
	                    resultPazienti.append("ID Paziente: ").append(parts[0]).append("\n");
	                    resultPazienti.append("Nome Paziente: ").append(parts[1]).append("\n");
	                    resultPazienti.append("Cognome Paziente: ").append(parts[2]).append("\n");
	                    resultPazienti.append("Telefono Paziente: ").append(parts[3]).append("\n");
	                    resultPazienti.append("id medico: ").append(parts[4]).append("\n\n");
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        DATIMEDICO.setText(resultMedico.toString());
	        DATIPAT.setText(resultPazienti.toString());
	    } else {
	        DATIMEDICO.setText("Medico non trovato!");
	    }
	}
	
	@FXML
	private void visualizzaDatiMediciPazienti(ActionEvent event) {
	    DATIMEDICO.clear();
	    DATIPAT.clear();

	    StringBuilder resultMedico = new StringBuilder();
	    StringBuilder resultPazienti = new StringBuilder();

	    try (BufferedReader mediciReader = new BufferedReader(new FileReader("dati_medici.txt"));
	         BufferedReader pazientiReader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {

	        String line;

	        while ((line = mediciReader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts.length >= 4) { 
	                resultMedico.append("ID: ").append(parts[0]).append("\n");
	                resultMedico.append("Nome: ").append(parts[1]).append("\n");
	                resultMedico.append("Cognome: ").append(parts[2]).append("\n");
	                resultMedico.append("Telefono: ").append(parts[3]).append("\n\n");
	            } else {
	                System.err.println("Dati incompleti per il medico: " + line);
	            }
	        }

	        while ((line = pazientiReader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts.length >= 5) { 
	                String medicoId = parts[4];
	                if (azienda.medicoEsiste(medicoId)) {
	                    resultPazienti.append("ID Paziente: ").append(parts[0]).append("\n");
	                    resultPazienti.append("Nome Paziente: ").append(parts[1]).append("\n");
	                    resultPazienti.append("Cognome Paziente: ").append(parts[2]).append("\n");
	                    resultPazienti.append("Telefono Paziente: ").append(parts[3]).append("\n");
	                    resultPazienti.append("Medico: ").append(parts[4]).append("\n\n");
	                } else {
	                    resultPazienti.append("ID Paziente: ").append(parts[0]).append("\n");
	                    resultPazienti.append("Nome Paziente: ").append(parts[1]).append("\n");
	                    resultPazienti.append("Cognome Paziente: ").append(parts[2]).append("\n");
	                    resultPazienti.append("Telefono Paziente: ").append(parts[3]).append("\n");
	                    resultPazienti.append("Medico: Il paziente non ha un medico di base").append("\n\n");
	                }
	            } else {
	                System.err.println("Dati incompleti per il paziente: " + line);
	            }
	        }

	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    DATIMEDICO.setText(resultMedico.toString());
	    DATIPAT.setText(resultPazienti.toString());
	}
*/


	
	@FXML
	private void modificaMedico(ActionEvent event) {
	    String medicoId = ciao.getText();
	    Medico medico = null;

	    try (Scanner scanner = new Scanner(new File("dati_medici.txt"))) {
	        while (scanner.hasNextLine()) {
	            String[] medicoData = scanner.nextLine().split(",");
	            String id = medicoData[0];
	            if (id.equals(medicoId)) {
	                medico = new Medico(id, medicoData[1], medicoData[2], medicoData[3]);
	                break;
	            }
	        }
	    } catch (FileNotFoundException e) {
	        System.err.println("Il file dati_medici.txt non � stato trovato.");
	        e.printStackTrace();
	    } catch (IOException e) { 
	        System.err.println("Errore durante la lettura del file dati_medici.txt.");
	        e.printStackTrace();
	    }

	    if (medico != null) {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("edit.fxml"));
	            Parent root = loader.load();
	            EditMedicController controller = loader.getController();
	            controller.initData(medico);
	            Stage stage = new Stage();
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	@FXML
	private void modificaPAT(ActionEvent event) {
	    String pazienteId = ciao.getText();
	    paziente paziente = null;

	    try (Scanner scanner = new Scanner(new File("dati_pazienti.txt"))) {
	        while (scanner.hasNextLine()) {
	            String[] pazienteData = scanner.nextLine().split(",");
	            String id = pazienteData[0];
	            if (id.equals(pazienteId)) {
	                paziente = new paziente(id, pazienteData[1], pazienteData[2], pazienteData[3], pazienteData[4]);
	                break;
	            }
	        }
	    } catch (FileNotFoundException e) {
	        System.err.println("Il file dati_pazienti.txt non � stato trovato.");
	        e.printStackTrace();
	    } catch (IOException e) { 
	        System.err.println("Errore durante la lettura del file dati_pazienti.txt.");
	        e.printStackTrace();
	    }

	    if (paziente != null) {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("editpat.fxml"));
	            Parent root = loader.load();
	            EditMedicController controller = loader.getController();
	            controller.initDataP(paziente);
	            Stage stage = new Stage();
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	@FXML
	private void DelMedico(ActionEvent event) {
	    String medicoId = ciao.getText();
	    boolean medicoTrovato = false;
	    List<Medico> mediciDaMantenere = new ArrayList<>();

	    try (Scanner scanner = new Scanner(new File("dati_medici.txt"))) {
	        while (scanner.hasNextLine()) {
	            String[] medicoData = scanner.nextLine().split(",");
	            String id = medicoData[0];
	            if (id.equals(medicoId)) {
	                medicoTrovato = true;
	                continue;
	            }
	            mediciDaMantenere.add(new Medico(id, medicoData[1], medicoData[2], medicoData[3]));
	        }
	    } catch (FileNotFoundException e) {
	        System.err.println("Il file dati_medici.txt non � stato trovato.");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.err.println("Errore durante la lettura del file dati_medici.txt.");
	        e.printStackTrace();
	    }

	    if (!medicoTrovato) {
	        System.err.println("Medico non trovato.");
	        return;
	    }

	    try (PrintWriter writer = new PrintWriter(new FileWriter("dati_medici.txt"))) {
	        for (Medico medico : mediciDaMantenere) {
	            writer.println(medico.getIdMedico() + "," + medico.getNome() + "," + medico.getCognome() + "," + medico.getTelefono());
	        }
	        System.out.println("Medico rimosso con successo.");
	        logger.scriviLog("Medico rimosso con successo. ID: " + medicoId);
	    } catch (IOException e) {
	        System.err.println("Errore durante la scrittura nel file dati_medici.txt.");
	        e.printStackTrace();
	    }
	}

	@FXML
	private void DelPatient(ActionEvent event) {
	    String pazienteId = ciao.getText();
	    boolean pazienteTrovato = false;
	    List<paziente> pazientiDaMantenere = new ArrayList<>();
	    try (Scanner scanner = new Scanner(new File("dati_pazienti.txt"))) {
	        while (scanner.hasNextLine()) {
	            String[] pazienteData = scanner.nextLine().split(",");
	            String id = pazienteData[0];
	            if (id.equals(pazienteId)) {
	                pazienteTrovato = true;
	                continue;
	            }            
	            pazientiDaMantenere.add(new paziente(id, pazienteData[1], pazienteData[2], pazienteData[3], pazienteData[4]));
	        }
	    } catch (FileNotFoundException e) {
	        System.err.println("Il file dati_pazienti.txt non � stato trovato.");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.err.println("Errore durante la lettura del file dati_pazienti.txt.");
	        e.printStackTrace();
	    }

	    if (!pazienteTrovato) {
	        System.err.println("Paziente non trovato.");
	        return;
	    }

	    try (PrintWriter writer = new PrintWriter(new FileWriter("dati_pazienti.txt"))) {
	        for (paziente paziente : pazientiDaMantenere) {
	            writer.println(paziente.getIdPaziente() + "," + paziente.getNome() + "," + paziente.getCognome() + "," + paziente.getTelefono() + "," + paziente.getMedico());
	        }
	        System.out.println("Paziente rimosso con successo.");
	        logger.scriviLog("Paziente rimosso con successo. ID: " + pazienteId);
	    } catch (IOException e) {
	        System.err.println("Errore durante la scrittura nel file dati_pazienti.txt.");
	        e.printStackTrace();
	    }
	}




	


}

	    



