package application;

import java.util.ArrayList;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;									

public class Medico {
	 
	    private final StringProperty idMedico ;
	    private final StringProperty nome;
	    private final StringProperty cognome;
 
	    private final StringProperty telefono;
	    private static ArrayList<paziente> pazienti;
	    public Medico(String idMedico, String nome, String cognome, String telefono) {
	        this.idMedico = new SimpleStringProperty(idMedico);
	        this.nome = new SimpleStringProperty(nome);
	        this.cognome = new SimpleStringProperty(cognome);
 
	        this.telefono = new SimpleStringProperty(telefono);
	        this.pazienti = new ArrayList<>();
	    }
	   

		public String getIdMedico() {
	        return idMedico.get();
	    }

	    public StringProperty idMedicoProperty() {
	        return idMedico;
	    }

	    public String getNome() {
	        return nome.get();
	    }

	    public StringProperty nomeProperty() {
	        return nome;
	    }

	    public String getCognome() {
	        return cognome.get();
	    }

	    public StringProperty cognomeProperty() {
	        return cognome;
	    }



	    public String getTelefono() {
	        return telefono.get();
	    }

	    public StringProperty telefonoProperty() {
	        return telefono;
	    }

	 
	    public void setIdMedico(String idMedico) {
	        this.idMedico.set(idMedico);
	    }

	   

	    public void setNome(String nome) {
	        this.nome.set(nome);
	    }

	   
	    public void setCognome(String cognome) {
	        this.cognome.set(cognome);
	    }

	  

	  
	    public void rimuoviPaziente(paziente paziente) {
	        if (pazienti.contains(paziente)) {
	            pazienti.remove(paziente);
	            paziente.setMedico(null);
	            logger.scriviLog("Rimosso paziente: " + paziente.getNome() + " " + paziente.getCognome() + " dal medico " + this.nome);
	        } else {
	            logger.scriviLog("Errore: il paziente non appartiene a questo medico.");
	        }
	    }
	  
	    public void aggiungiPaziente(paziente paziente) {
	        pazienti.add(paziente);
	    }
	    public ArrayList<paziente> getPazienti() {
	        return pazienti;
	    }
	    public void setTelefono(String telefono) {
	        this.telefono.set(telefono);
	    }

	    @Override
	    public String toString() {
	        return idMedico.get() + "," + nome.get() + "," + cognome.get() +  "," + telefono.get();
	    }

		
		

		
	}


